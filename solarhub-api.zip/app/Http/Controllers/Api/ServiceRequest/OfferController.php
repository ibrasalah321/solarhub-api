<?php

namespace App\Http\Controllers\Api\ServiceRequest;

use App\Http\Controllers\Controller;
use App\Http\Requests\ServiceRequest\StoreOfferRequest;
use App\Http\Requests\ServiceRequest\UpdateOfferRequest;
use App\Http\Resources\ServiceRequest\OfferResource;
use App\Models\Offer;
use App\Models\ServiceRequest;
use App\Services\Engineer\EngineerProfileService;
use App\Services\Notification\DomainNotificationDispatcher;
use App\Services\ServiceRequest\OfferService;
use App\Traits\ApiResponseTrait;
use Illuminate\Http\Request;

class OfferController extends Controller
{
    use ApiResponseTrait;

    public function __construct(
        private readonly OfferService $offerService,
        private readonly EngineerProfileService $engineerProfileService,
        private readonly DomainNotificationDispatcher $notifications
    ) {}

    public function store(StoreOfferRequest $request, ServiceRequest $serviceRequest)
    {
        $engineer = $this->engineerProfileService
            ->getMyProfile($request->user());

        if (! $engineer) {
            return $this->errorResponse(
                'Engineer profile not found.',
                null,
                404
            );
        }

        $offer = $this->offerService->create(
            $engineer,
            $serviceRequest,
            $request->validated()
        );
        $offer->loadMissing('serviceRequest.customer');

        $this->notifications->offerSubmitted(
            $request->user(),
            $offer
        );

        return $this->successResponse(
            new OfferResource($offer),
            'Offer submitted successfully.',
            201
        );
    }

    public function myOffers(Request $request)
    {
        $engineer = $this->engineerProfileService
            ->getMyProfile($request->user());

        if (! $engineer) {
            return $this->errorResponse(
                'Engineer profile not found.',
                null,
                404
            );
        }

        $offers = $this->offerService
            ->getEngineerOffers($engineer);

        return $this->successResponse(
            OfferResource::collection($offers),
            'Offers retrieved successfully.'
        );
    }

    public function update(UpdateOfferRequest $request, Offer $offer)
    {
        $engineer = $this->engineerProfileService
            ->getMyProfile($request->user());

        if (! $engineer) {
            return $this->errorResponse(
                'Engineer profile not found.',
                null,
                404
            );
        }

        $offer = $this->offerService->update(
            $engineer,
            $offer,
            $request->validated()
        );

        return $this->successResponse(
            new OfferResource($offer),
            'Offer updated successfully.'
        );
    }

    public function destroy(Request $request, Offer $offer)
    {
        $engineer = $this->engineerProfileService
            ->getMyProfile($request->user());

        if (! $engineer) {
            return $this->errorResponse(
                'Engineer profile not found.',
                null,
                404
            );
        }

        $this->offerService->delete(
            $engineer,
            $offer
        );

        return $this->successResponse(
            null,
            'Offer deleted successfully.'
        );
    }

    public function requestOffers(Request $request, ServiceRequest $serviceRequest)
    {
        $offers = $this->offerService->getRequestOffers(
            $request->user(),
            $serviceRequest
        );

        return $this->successResponse(
            OfferResource::collection($offers),
            'Offers retrieved successfully.'
        );
    }

    public function accept(Request $request, Offer $offer)
    {
        $offer = $this->offerService->accept(
            $request->user(),
            $offer
        );

        $this->notifications->offerAccepted(
            $request->user(),
            $offer
        );

        return $this->successResponse(
            new OfferResource($offer),
            'Offer accepted successfully.'
        );
    }
}

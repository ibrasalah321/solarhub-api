<?php

namespace App\Http\Resources\Catalog;

use App\Services\SupabaseStorageService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BrandResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'logo_url' => app(SupabaseStorageService::class)->publicUrl($this->logo),
            'website' => $this->website,
            'is_active' => $this->is_active,
            'products_count' => $this->whenCounted('masterProducts'),
            'created_at' => $this->created_at,
        ];
    }
}

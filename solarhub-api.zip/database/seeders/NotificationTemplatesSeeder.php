<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class NotificationTemplatesSeeder extends Seeder
{
    public function run(): void
    {
        $templates = [
            [
                'slug' => 'order_placed',
                'title_template' => 'طلب شراء جديد',
                'body_template' => 'تم استلام طلبكم رقم {order_number} بنجاح.',
                'is_active' => true,
            ],
            [
                'slug' => 'order_shipped',
                'title_template' => 'شحن الطلب',
                'body_template' => 'قام المتجر بشحن طلبكم رقم {order_number}.',
                'is_active' => true,
            ],
            [
                'slug' => 'quote_received',
                'title_template' => 'عرض سعر جديد',
                'body_template' => 'تلقيت عرض سعر جديد لطلبك من أحد المهندسين.',
                'is_active' => true,
            ],
        ];

        foreach ($templates as $tmpl) {
            DB::table('notification_templates')->updateOrInsert(
                ['slug' => $tmpl['slug']],
                array_merge($tmpl, ['created_at' => now(), 'updated_at' => now()])
            );
        }
    }
}

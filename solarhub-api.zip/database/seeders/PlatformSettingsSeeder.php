<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PlatformSettingsSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            ['key' => 'commission_rate', 'value' => '0.05', 'description' => 'عمولة المنصة على المبيعات 5%'],
            ['key' => 'default_currency', 'value' => 'USD', 'description' => 'العملة الأساسية للتسعير'],
            ['key' => 'min_payout_amount', 'value' => '100', 'description' => 'الحد الأدنى لطلب سحب أرباح المتجر'],
        ];

        foreach ($settings as $setting) {
            DB::table('platform_settings')->updateOrInsert(
                ['key' => $setting['key']],
                array_merge($setting, ['created_at' => now(), 'updated_at' => now()])
            );
        }
    }
}

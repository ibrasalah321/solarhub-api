<?php

namespace Database\Factories;

use App\Models\QuoteRequest;
use App\Models\User;
use App\Models\Governorate;
use Illuminate\Database\Eloquent\Factories\Factory;

class QuoteRequestFactory extends Factory
{
    protected $model = QuoteRequest::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory()->state(['user_type' => 'customer']),
            'governorate_id' => Governorate::inRandomOrder()->first()?->id,
            'title' => 'طلب تسعير منظومة ' . fake()->randomElement(['5kW', '10kW', 'طاقة شمسية زراعية']),
            'description' => fake()->paragraph(),
            'status' => fake()->randomElement(['pending', 'quoted', 'closed']),
        ];
    }
}

import hashlib, json, re, unicodedata
import pdfplumber
from pathlib import Path

SOURCE = Path(r"C:\Users\Elite\Desktop\منتجات_الطاقة_الشمسية_المتاحة_في_السوق_اليمني.pdf")
OUTPUT = Path(r"C:\xamppp\htdocs\product_wep\solarhub-api\database\data\solar_catalog_yemen.json")

brands = [
    "Jinko Solar", "LONGi", "Kenza", "Trina Solar", "ADDO", "Eastman",
    "Long", "SVOLT", "Ever Exide", "Pylontech", "Raw Power", "Sunshine",
    "JC Green", "Bates", "BYD", "Noor Power", "Moody", "Energy Promax",
    "Vision", "Rafal", "Riyah Aden", "Deye", "GSB", "Renon", "Felicity",
    "ATess", "Dyness", "Growatt", "Lux Power", "Sungrow", "OPTI-Solar",
    "Katrina", "Most", "Powerlite", "RAGGIE", "Cobox", "Ducab", "Shakti",
    "Schingofo", "LS",
]

def logical(text):
    if not text:
        return ""
    lines = []
    for raw_line in str(text).splitlines():
        value = unicodedata.normalize("NFKC", raw_line[::-1]).strip()
        def restore_ascii(match):
            tokens = match.group(0).split()
            return " ".join(token[::-1] for token in reversed(tokens))
        value = re.sub(r"[A-Za-z0-9][A-Za-z0-9._/+()\-]*(?:\s+[A-Za-z0-9][A-Za-z0-9._/+()\-]*)*", restore_ascii, value)
        value = re.sub(r"\s+", " ", value).strip()
        if value:
            lines.append(value)
    return " - ".join(reversed(lines))

def category_for(text):
    checks = [
        ("solar-panels", ["لوح شمسي"]),
        ("batteries", ["بطارية"]),
        ("inverters", ["إنفرتر", "محول"]),
        ("charge-controllers", ["منظم شحن"]),
        ("solar-water-heaters", ["سخان شمسي"]),
        ("solar-air-conditioners", ["مكيف طاقة شمسية"]),
        ("solar-pumps", ["مضخة شمسية", "غطاس"]),
        ("solar-lighting", ["كشاف شمسي"]),
        ("protection-monitoring", ["صندوق حماية", "قاطع/جهاز مراقبة"]),
        ("cables-connectors", ["سلك/كابل"]),
        ("installation-accessories", ["مستلزم تركيب"]),
        ("battery-chargers", ["شاحن بطاريات"]),
    ]
    for slug, needles in checks:
        if any(needle in text for needle in needles):
            return slug
    return None

records = []
seen = set()
with pdfplumber.open(SOURCE) as pdf:
    for page_number, page in enumerate(pdf.pages, 1):
        for table in page.extract_tables():
            for row in table:
                cells = [logical(cell) for cell in row if cell is not None]
                if not cells:
                    continue
                joined = " | ".join(cells)
                if "الاسم" in joined and "النوع" in joined:
                    continue
                category = category_for(joined)
                if category is None:
                    continue
                title = cells[0].strip(" -")
                section_headings = {
                    "الاسم", "النوع", "بطارية", "إنفرتر", "إنفرتر/محول",
                    "منظم شحن", "سخان شمسي", "مكيف طاقة شمسية",
                    "غطاس/مضخة شمسية", "كشاف شمسي", "صندوق حماية",
                    "قاطع/جهاز مراقبة", "سلك/كابل", "مستلزم تركيب",
                    "شاحن بطاريات",
                }
                if not title or title in section_headings or len(title) > 200:
                    continue
                searchable = " ".join(str(cell or "") for cell in row)
                brand = next((name for name in brands if re.search(r"(?<![A-Za-z])" + re.escape(name) + r"(?![A-Za-z])", searchable, re.I)), "غير مذكورة")
                capacity = cells[-1].strip(" -") if len(cells) >= 2 else ""
                if capacity in {"غير مذكور", "غير محدد", "غير مذكورة"} or "القدرة/الحجم" in capacity:
                    capacity = None
                identity = f"{category}|{brand.casefold()}|{title.casefold()}|{(capacity or '').casefold()}"
                if identity in seen:
                    continue
                seen.add(identity)
                source_key = hashlib.sha256(f"solar-yemen-pdf|{identity}".encode("utf-8")).hexdigest()
                records.append({
                    "source_key": source_key,
                    "source_page": page_number,
                    "category": category,
                    "brand": brand,
                    "title": title,
                    "model_number": None,
                    "capacity": capacity,
                    "source_notes": None if capacity else "القدرة أو الحجم غير مذكور بوضوح في المصدر.",
                })

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
OUTPUT.write_text(json.dumps({
    "source": SOURCE.name,
    "page_count": 19,
    "records": records,
}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"records={len(records)}")
from collections import Counter
print("categories", dict(Counter(r["category"] for r in records)))
print("unknown_brands", sum(r["brand"] == "غير مذكورة" for r in records))